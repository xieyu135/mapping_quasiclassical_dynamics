
program=$HOME/xieyu/program

